package com.example.luxe;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.HashMap;
import java.util.Map;

public class ShowAllServices extends AppCompatActivity {

    private LinearLayout servicesLayout;
    private FirebaseFirestore fStore;
    private Map<String, String> userCache = new HashMap<>(); // Caching user data for efficiency

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_services2);

        fStore = FirebaseFirestore.getInstance();
        servicesLayout = findViewById(R.id.servicesLayout);

        // Fetch and display all services
        fetchAllServices();
    }

    private void fetchAllServices() {
        fStore.collectionGroup("reservations")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String userId = document.getString("userId");
                            if (userId != null) {
                                fetchUserNameAndDisplayService(userId, document);
                            }
                        }
                    } else {
                        showNoServicesMessage();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to load services.", Toast.LENGTH_SHORT).show());
    }

    private void fetchUserNameAndDisplayService(String userId, QueryDocumentSnapshot serviceDocument) {
        if (userCache.containsKey(userId)) {
            displayServiceInfo(userCache.get(userId), serviceDocument);
        } else {
            fStore.collection("Users").document(userId)
                    .get()
                    .addOnSuccessListener(userDocument -> {
                        if (userDocument.exists()) {
                            String userName = userDocument.getString("Full Name");
                            if (userName != null) {
                                userCache.put(userId, userName);
                                displayServiceInfo(userName, serviceDocument);
                            }
                        }
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to load user information.", Toast.LENGTH_SHORT).show());
        }
    }

    private void displayServiceInfo(String userName, QueryDocumentSnapshot document) {
        String serviceName = document.getString("serviceName");
        String reservationDate = document.getString("reservationDate");
        final String serviceId = document.getId();

        View serviceItemView = getLayoutInflater().inflate(R.layout.service_item_admin, null);
        TextView serviceInfoText = serviceItemView.findViewById(R.id.serviceInfoText);
        Button deleteButton = serviceItemView.findViewById(R.id.deleteButton);

        serviceInfoText.setText(
                "User: " + userName + "\n" +
                        "Service: " + serviceName + "\n" +
                        "Reservation Date: " + reservationDate
        );

        deleteButton.setOnClickListener(v -> deleteService(serviceId));

        servicesLayout.addView(serviceItemView);
    }

    private void deleteService(final String serviceId) {
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to delete this service?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    fStore.collectionGroup("reservations")
                            .whereEqualTo("id", serviceId)
                            .get()
                            .addOnSuccessListener(querySnapshots -> {
                                if (!querySnapshots.isEmpty()) {
                                    querySnapshots.getDocuments().get(0).getReference().delete()
                                            .addOnSuccessListener(aVoid -> {
                                                Toast.makeText(ShowAllServices.this, "Service deleted.", Toast.LENGTH_SHORT).show();
                                                servicesLayout.removeAllViews();
                                                fetchAllServices();
                                            })
                                            .addOnFailureListener(e -> Toast.makeText(ShowAllServices.this, "Failed to delete service.", Toast.LENGTH_SHORT).show());
                                }
                            });
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void showNoServicesMessage() {
        TextView noServicesView = new TextView(this);
        noServicesView.setText("No services found.");
        noServicesView.setPadding(16, 16, 16, 16);
        servicesLayout.addView(noServicesView);
    }
}
