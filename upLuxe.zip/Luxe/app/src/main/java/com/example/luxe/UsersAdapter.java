package com.example.luxe;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UsersAdapter extends RecyclerView.Adapter<UsersAdapter.UserViewHolder> {

    private ArrayList<User> userList;

    public UsersAdapter(ArrayList<User> userList) {
        this.userList = userList;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_item, parent, false);
        return new UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        User currentUser = userList.get(position);
        holder.txtUsername.setText("Username: " + currentUser.getFullName());
        holder.txtPhone.setText("Phone: " + currentUser.getPhone());
        holder.txtEmail.setText("Email: " + currentUser.getEmail());
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView txtUsername, txtPhone, txtEmail;

        public UserViewHolder(View itemView) {
            super(itemView);
            txtUsername = itemView.findViewById(R.id.TXT_Username);
            txtPhone = itemView.findViewById(R.id.TXT_Phone);
            txtEmail = itemView.findViewById(R.id.TXT_Email);
        }
    }
}
