package com.example.luxe;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class showusers extends AppCompatActivity {

    FirebaseFirestore fStore;
    RecyclerView recyclerView;
    UsersAdapter usersAdapter;
    ArrayList<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showusers);

        // Initialize Firebase Firestore
        fStore = FirebaseFirestore.getInstance();

        // Initialize the RecyclerView and the user list
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userList = new ArrayList<>();
        usersAdapter = new UsersAdapter(userList);
        recyclerView.setAdapter(usersAdapter);

        // Fetch all users from the Firestore
        fStore.collection("Users")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Loop through all the documents in the "Users" collection
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Extract user data
                            String fullName = document.getString("Full Name");
                            String phone = document.getString("Phone");
                            String email = document.getString("Email");

                            // Create a new User object and add to the list
                            if (fullName != null && phone != null && email != null) {
                                userList.add(new User(fullName, phone, email));
                            }
                        }
                        // Notify the adapter that the data has changed
                        usersAdapter.notifyDataSetChanged();
                    } else {
                        // Handle the error if the task fails
                        Toast.makeText(showusers.this, "Failed to load user data", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
