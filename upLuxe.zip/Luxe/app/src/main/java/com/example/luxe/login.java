package com.example.luxe;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class login extends AppCompatActivity {

    EditText etxt_email, etxt_password;
    Button btn_login;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    // Hardcoded admin credentials (username and password)
    private static final String ADMIN_EMAIL = "admin@1.com";
    private static final String ADMIN_PASSWORD = "admin123"; // You can change this to any secure password

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize Firebase
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        // Link UI components
        etxt_email = findViewById(R.id.ETXT_mail);
        etxt_password = findViewById(R.id.ETXT_password);
        btn_login = findViewById(R.id.BTN_Login);

        // Handle login button click
        btn_login.setOnClickListener(view -> {
            String email = etxt_email.getText().toString().trim();
            String pass = etxt_password.getText().toString().trim();

            // Validate inputs
            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(login.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the user is an admin (hardcoded)
            if (email.equals(ADMIN_EMAIL) && pass.equals(ADMIN_PASSWORD)) {
                Intent adminIntent = new Intent(login.this, adminDashboard.class); // Create an Admin Dashboard Activity
                startActivity(adminIntent);
                finish();
            } else {
                // Attempt regular user login
                fAuth.signInWithEmailAndPassword(email, pass)
                        .addOnSuccessListener(authResult -> {
                            // Fetch user information from Firestore
                            String userId = fAuth.getCurrentUser().getUid();
                            fStore.collection("Users").document(userId)
                                    .get()
                                    .addOnSuccessListener(documentSnapshot -> {
                                        if (documentSnapshot.exists()) {
                                            // Get the username from Firestore
                                            String username = documentSnapshot.getString("Full Name");

                                            // Pass the username to the Menu activity
                                            Intent intent = new Intent(login.this, Menu.class);
                                            intent.putExtra("username", username);  // Pass username here
                                            startActivity(intent);
                                            finish();
                                        }
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(login.this, "Failed to fetch user info: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    });
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(login.this, "Login Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
            }
        });
    }
}
