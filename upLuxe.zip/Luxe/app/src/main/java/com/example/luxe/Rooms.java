package com.example.luxe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Rooms extends AppCompatActivity {
    Button btn_Oceanroom, btnDeluxroom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rooms);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btn_Oceanroom = findViewById(R.id.BTNOcenaRoom);
        btnDeluxroom = findViewById(R.id.BTNdulexRoom);

        btn_Oceanroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveToOceanRoom = new Intent(getApplicationContext(), oceanroom.class); // Updated to OceanRoom
                startActivity(moveToOceanRoom);
            }
        });


        btnDeluxroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveToDeluxRoom = new Intent(getApplicationContext(), deluxroom.class);
                startActivity(moveToDeluxRoom);
            }
        });
    }
}