package com.example.luxe;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class userinfor extends AppCompatActivity {

    private TextView txtToolbarTitle;  // TextView for toolbar title
    private LinearLayout bookingsLayout; // Layout to dynamically add booking information
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfor);

        // Initialize FirebaseAuth and FirebaseFirestore
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        // Initialize views
        txtToolbarTitle = findViewById(R.id.txtToolbarTitle);  // Initialize toolbar title TextView
        bookingsLayout = findViewById(R.id.bookingsLayout);

        // Apply window insets for handling status bar and navigation bar on modern devices
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Check if user is logged in
        if (fAuth.getCurrentUser() != null) {
            String userId = fAuth.getCurrentUser().getUid(); // Get current user ID

            // Fetch and display the username
            fStore.collection("Users").document(userId)
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String username = documentSnapshot.getString("Full Name");
                            txtToolbarTitle.setText(username != null ? "Reservation Information of, " + username : "Reservation Information");
                        }
                    })
                    .addOnFailureListener(e -> txtToolbarTitle.setText("Hi, User"));

            // Fetch room bookings for the user
            fStore.collection("hotelroom")
                    .whereEqualTo("User ID", userId)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                displayRoomBookingInfo(document);
                            }
                        } else {
                            showNoRoomBookingsMessage();
                        }
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to load room bookings.", Toast.LENGTH_SHORT).show());

            // Fetch service bookings for the user
            fStore.collection("services").document(userId)
                    .collection("reservations")
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                displayServiceBookingInfo(document);
                            }
                        } else {
                            showNoServiceBookingsMessage();
                        }
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to load service bookings.", Toast.LENGTH_SHORT).show());
        } else {
            txtToolbarTitle.setText("Hi, User");
            showNoRoomBookingsMessage();
            showNoServiceBookingsMessage();
        }
    }

    private void displayRoomBookingInfo(QueryDocumentSnapshot document) {
        // Extract room booking data
        String roomType = document.getString("Room Type");
        String checkInDate = document.getString("Check-In Date");
        String checkOutDate = document.getString("Check-Out Date");
        String adults = document.getString("Adults");
        String children = document.getString("Children");

        // Create a TextView to display the room booking information
        TextView bookingView = new TextView(this);
        bookingView.setText(
                "Room Booking:\n" +
                        "Room Type: " + roomType + "\n" +
                        "Check-In: " + checkInDate + "\n" +
                        "Check-Out: " + checkOutDate + "\n" +
                        "Adults: " + adults + "\n" +
                        "Children: " + children
        );
        bookingView.setPadding(16, 16, 16, 16);
        bookingView.setBackgroundResource(R.drawable.booking_info_background);  // Ensure this drawable exists
        bookingsLayout.addView(bookingView);
    }

    private void displayServiceBookingInfo(QueryDocumentSnapshot document) {
        // Extract service booking data
        String serviceName = document.getString("serviceName");

        // Create a TextView to display the service booking information
        TextView serviceView = new TextView(this);
        serviceView.setText(
                "Service Booking:\n" +
                        "Service Name: " + serviceName
        );
        serviceView.setPadding(16, 16, 16, 16);
        serviceView.setBackgroundResource(R.drawable.booking_info_background);  // Ensure this drawable exists
        bookingsLayout.addView(serviceView);
    }

    private void showNoRoomBookingsMessage() {
        TextView noBookingsView = new TextView(this);
        noBookingsView.setText("No room bookings found.");
        noBookingsView.setPadding(16, 16, 16, 16);
        bookingsLayout.addView(noBookingsView);
    }

    private void showNoServiceBookingsMessage() {
        TextView noServiceView = new TextView(this);
        noServiceView.setText("No service bookings found.");
        noServiceView.setPadding(16, 16, 16, 16);
        bookingsLayout.addView(noServiceView);
    }
}
