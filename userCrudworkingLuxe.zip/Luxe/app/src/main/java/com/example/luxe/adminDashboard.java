package com.example.luxe;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.auth.FirebaseAuth;

public class adminDashboard extends AppCompatActivity {

    CardView btn_showuser, btn_edituser, btn_showbooking;
    Button logout_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        // Initialize the views
        btn_showuser = findViewById(R.id.BTN_showUsers);
        btn_showbooking = findViewById(R.id.BTN_showBookins);
        logout_button = findViewById(R.id.BTN_Logout);

        btn_showuser.setOnClickListener(view -> {
            Intent moveShowUser = new Intent(adminDashboard.this, showusers.class);
            startActivity(moveShowUser);
        });

        btn_showbooking.setOnClickListener(view -> {
            Intent moveShowBookings = new Intent(adminDashboard.this, ShowAllBookings.class);
            startActivity(moveShowBookings);
        });

        // Logout Button functionality
        logout_button.setOnClickListener(view -> {
            // Sign out from Firebase
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(adminDashboard.this, "Logged Out Successfully", Toast.LENGTH_SHORT).show();
            // Redirect to Login activity after logout
            startActivity(new Intent(adminDashboard.this, login.class));
            finish();
        });
    }
}
