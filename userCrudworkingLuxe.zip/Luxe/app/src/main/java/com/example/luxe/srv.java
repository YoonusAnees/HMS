package com.example.luxe;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class srv extends AppCompatActivity {
    ImageView toggle_icon;
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srv);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        Button reserveButton1 = findViewById(R.id.reserveButton1);
        Button reserveButton2 = findViewById(R.id.reserveButton2);
        Button reserveButton3 = findViewById(R.id.reserveButton3);

        reserveButton1.setOnClickListener(view -> reserveService("Spa Treatment"));
        reserveButton2.setOnClickListener(view -> reserveService("Fine Dining"));
        reserveButton3.setOnClickListener(view -> reserveService("Poolside Cabana"));

        toggle_icon = findViewById(R.id.toggle_icon);
        toggle_icon.setOnClickListener(view -> {
            Intent intent = new Intent(srv.this, Menu.class);
            startActivity(intent);
        });
    }

    private void reserveService(String serviceName) {
        String userId = fAuth.getCurrentUser().getUid();

        if (userId != null) {
            fStore.collection("services")
                    .document(userId)
                    .collection("reservations")  // Subcollection to store multiple reservations for each user
                    .add(new ServiceReservation(serviceName)) // Store the service reservation
                    .addOnSuccessListener(documentReference -> {
                        // Reservation successful
                        Toast.makeText(srv.this, "Service Reserved: " + serviceName, Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        // Handle failure
                        Toast.makeText(srv.this, "Failed to reserve service: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(srv.this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper class to represent the service reservation data
    public static class ServiceReservation {
        String serviceName;

        public ServiceReservation(String serviceName) {
            this.serviceName = serviceName;
        }

        public String getServiceName() {
            return serviceName;
        }
    }
}
