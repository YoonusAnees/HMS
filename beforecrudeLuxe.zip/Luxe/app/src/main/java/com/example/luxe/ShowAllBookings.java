package com.example.luxe;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.HashMap;
import java.util.Map;

public class ShowAllBookings extends AppCompatActivity {

    private TextView txtToolbarTitle; // Toolbar title
    private LinearLayout bookingsLayout; // Layout for dynamically adding booking info
    private FirebaseFirestore fStore; // Firestore instance
    private Map<String, String> userCache = new HashMap<>(); // Cache for storing user IDs and names

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_bookings);

        // Initialize Firestore and views
        fStore = FirebaseFirestore.getInstance();
        txtToolbarTitle = findViewById(R.id.txtToolbarTitle);
        bookingsLayout = findViewById(R.id.bookingsLayout);

        // Apply window insets for modern devices
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set toolbar title
        txtToolbarTitle.setText("All Bookings Information");

        // Fetch and display all bookings
        fetchAllBookings();
    }

    private void fetchAllBookings() {
        // Fetch all room bookings
        fStore.collection("hotelroom")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String userId = document.getString("User ID");
                            if (userId != null) {
                                fetchUserNameAndDisplayBooking(userId, document);
                            }
                        }
                    } else {
                        showNoRoomBookingsMessage();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to load room bookings.", Toast.LENGTH_SHORT).show());
    }

    private void fetchUserNameAndDisplayBooking(String userId, QueryDocumentSnapshot bookingDocument) {
        // Check if user name is already cached
        if (userCache.containsKey(userId)) {
            displayRoomBookingInfo(userCache.get(userId), bookingDocument);
        } else {
            // Fetch user name from Firestore
            fStore.collection("Users").document(userId)
                    .get()
                    .addOnSuccessListener(userDocument -> {
                        if (userDocument.exists()) {
                            String userName = userDocument.getString("Full Name");
                            if (userName != null) {
                                userCache.put(userId, userName); // Cache the user name
                                displayRoomBookingInfo(userName, bookingDocument);
                            }
                        }
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to load user information.", Toast.LENGTH_SHORT).show());
        }
    }

    private void displayRoomBookingInfo(String userName, QueryDocumentSnapshot document) {
        // Extract room booking data
        String roomType = document.getString("Room Type");
        String checkInDate = document.getString("Check-In Date");
        String checkOutDate = document.getString("Check-Out Date");
        String adults = document.getString("Adults");
        String children = document.getString("Children");

        // Create a TextView to display the room booking information
        TextView bookingView = new TextView(this);
        bookingView.setText(
                "User: " + userName + "\n" +
                        "Room Booking:\n" +
                        "Room Type: " + roomType + "\n" +
                        "Check-In: " + checkInDate + "\n" +
                        "Check-Out: " + checkOutDate + "\n" +
                        "Adults: " + adults + "\n" +
                        "Children: " + children
        );
        bookingView.setPadding(16, 16, 16, 16);
        bookingView.setBackgroundResource(R.drawable.booking_info_background);  // Ensure this drawable exists
        bookingsLayout.addView(bookingView);
    }

    private void showNoRoomBookingsMessage() {
        TextView noBookingsView = new TextView(this);
        noBookingsView.setText("No room bookings found.");
        noBookingsView.setPadding(16, 16, 16, 16);
        bookingsLayout.addView(noBookingsView);
    }
}
