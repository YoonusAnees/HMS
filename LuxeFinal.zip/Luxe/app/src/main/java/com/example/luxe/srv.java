package com.example.luxe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class srv extends AppCompatActivity {

    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srv);

        // Initialize Firebase
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        // Define UI elements for the buttons
        Button reserveButton1 = findViewById(R.id.reserveButton1);
        Button reserveButton2 = findViewById(R.id.reserveButton2);
        Button reserveButton3 = findViewById(R.id.reserveButton3);

        // Handle service reservation for Service 1 (Spa Treatment)
        reserveButton1.setOnClickListener(view -> reserveService("Spa Treatment"));

        // Handle service reservation for Service 2 (Fine Dining)
        reserveButton2.setOnClickListener(view -> reserveService("Fine Dining"));

        // Handle service reservation for Service 3 (Poolside Cabana)
        reserveButton3.setOnClickListener(view -> reserveService("Poolside Cabana"));
    }

    // Method to handle service reservation
    private void reserveService(String serviceName) {
        String userId = fAuth.getCurrentUser().getUid(); // Get the current user ID

        if (userId != null) {
            // Create a new document in the "services" collection with the user's ID and service information
            fStore.collection("services")
                    .document(userId)
                    .collection("reservations")  // Subcollection to store multiple reservations for each user
                    .add(new ServiceReservation(serviceName)) // Store the service reservation
                    .addOnSuccessListener(documentReference -> {
                        // Reservation successful
                        Toast.makeText(srv.this, "Service Reserved: " + serviceName, Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        // Handle failure
                        Toast.makeText(srv.this, "Failed to reserve service: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(srv.this, "User not logged in", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper class to represent the service reservation data
    public static class ServiceReservation {
        String serviceName;

        public ServiceReservation(String serviceName) {
            this.serviceName = serviceName;
        }

        public String getServiceName() {
            return serviceName;
        }
    }
}
